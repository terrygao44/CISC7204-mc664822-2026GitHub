CISC7204 Assignment 02 - Project Space
======================================

Module 04 - Lab02: Dash Basics

Pair            : Class K - Pair 05
Member          : MC664822 GAO TE
Pair partner    : MC664831 WEN ZIMING
Coursework item : CISC7204 Assignment 02 - Modules (01-05)
UMMoodle site   : Class K support site (26-1-CISC7204-00__72314)

Contents
--------
  dash_basics.py
  Screenshots/Module04_Lab02_app_s01_initial.png
      Running dashboard: initial view (pie chart of average price by number of bedrooms)
  Screenshots/Module04_Lab02_code_dash_basics_code_p1.png
      Source code (dash_basics.py), page 1

Notes
-----
Run with: python dash_basics.py  then open the local Dash URL reported in the console.

All screenshots in the Screenshots folder were captured from the actual execution of
the script(s) above by MC664822 GAO TE. The Jupyter Notebook evidence for the same module is
submitted separately in the personal forum of the module.
