CISC7204 Assignment 02 - Project Space
======================================

Module 04 - Lab04: Flight Delay Time Statistics Dashboard

Pair            : Class K - Pair 05
Member          : MC664822 GAO TE
Pair partner    : MC664831 WEN ZIMING
Coursework item : CISC7204 Assignment 02 - Modules (01-05)
UMMoodle site   : Class K support site (26-1-CISC7204-00__72314)

Contents
--------
  flight_delay.py
  Screenshots/Module04_Lab04_app_s01_initial.png
      Flight delay dashboard - initial view (year 2010)
  Screenshots/Module04_Lab04_app_s02_year_2007.png
      Flight delay dashboard - after selecting year 2007 (all five charts update)
  Screenshots/Module04_Lab04_code_flight_delay_code_p1.png
      Source code (flight_delay.py), page 1
  Screenshots/Module04_Lab04_code_flight_delay_code_p2.png
      Source code (flight_delay.py), page 2
  Screenshots/Module04_Lab04_code_flight_delay_code_p3.png
      Source code (flight_delay.py), page 3

Notes
-----
Run with: python flight_delay.py

All screenshots in the Screenshots folder were captured from the actual execution of
the script(s) above by MC664822 GAO TE. The Jupyter Notebook evidence for the same module is
submitted separately in the personal forum of the module.
