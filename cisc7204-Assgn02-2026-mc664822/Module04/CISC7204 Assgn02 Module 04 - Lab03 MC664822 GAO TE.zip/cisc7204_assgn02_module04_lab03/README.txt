CISC7204 Assignment 02 - Project Space
======================================

Module 04 - Lab03: Add Interactivity - User Input and Callbacks

Pair            : Class K - Pair 05
Member          : MC664822 GAO TE
Pair partner    : MC664831 WEN ZIMING
Coursework item : CISC7204 Assignment 02 - Modules (01-05)
UMMoodle site   : Class K support site (26-1-CISC7204-00__72314)

Contents
--------
  dash_interactivity.py
  dash_interactivity_barplot.py
  Screenshots/Module04_Lab03_app_dash_interactivity_s01_initial.png
      dash_interactivity.py - initial view
  Screenshots/Module04_Lab03_app_dash_interactivity_s02_year_2007.png
      dash_interactivity.py - after selecting year 2007 in the dropdown (callback fired)
  Screenshots/Module04_Lab03_app_dash_interactivity_barplot_s01_initial.png
      dash_interactivity_barplot.py - initial view
  Screenshots/Module04_Lab03_app_dash_interactivity_barplot_s02_year_2007.png
      dash_interactivity_barplot.py - after selecting year 2007
  Screenshots/Module04_Lab03_code_dash_interactivity_code_p1.png
      Source code (dash_interactivity.py), page 1
  Screenshots/Module04_Lab03_code_dash_interactivity_code_p2.png
      Source code (dash_interactivity.py), page 2
  Screenshots/Module04_Lab03_code_dash_interactivity_barplot_code_p1.png
      Source code (dash_interactivity_barplot.py), page 1
  Screenshots/Module04_Lab03_code_dash_interactivity_barplot_code_p2.png
      Source code (dash_interactivity_barplot.py), page 2

Notes
-----
Two Dash applications are included: the guided interactivity app and the bar-plot exercise.

All screenshots in the Screenshots folder were captured from the actual execution of
the script(s) above by MC664822 GAO TE. The Jupyter Notebook evidence for the same module is
submitted separately in the personal forum of the module.
