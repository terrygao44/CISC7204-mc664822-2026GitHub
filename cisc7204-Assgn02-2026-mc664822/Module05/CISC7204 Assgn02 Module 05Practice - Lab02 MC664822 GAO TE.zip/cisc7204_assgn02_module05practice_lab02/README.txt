CISC7204 Assignment 02 - Project Space
======================================

Module 05 Practice - Lab02: Creating Dashboards (Australian Wildfire)

Pair            : Class K - Pair 05
Member          : MC664822 GAO TE
Pair partner    : MC664831 WEN ZIMING
Coursework item : CISC7204 Assignment 02 - Modules (01-05)
UMMoodle site   : Class K support site (26-1-CISC7204-00__72314)

Contents
--------
  Dash_wildfire.py
  Screenshots/Module05_PracticeLab02_app_s01_initial.png
      Wildfire dashboard - initial view (region: New South Wales)
  Screenshots/Module05_PracticeLab02_app_s02_region_northern_territory.png
      Wildfire dashboard - region switched to Northern Territory (callbacks update both charts)
  Screenshots/Module05_PracticeLab02_app_s03_year_2006.png
      Wildfire dashboard - year switched to 2006
  Screenshots/Module05_PracticeLab02_code_Dash_wildfire_code_p1.png
      Source code (Dash_wildfire.py), page 1
  Screenshots/Module05_PracticeLab02_code_Dash_wildfire_code_p2.png
      Source code (Dash_wildfire.py), page 2
  Screenshots/Module05_PracticeLab02_code_Dash_wildfire_code_p3.png
      Source code (Dash_wildfire.py), page 3

Notes
-----
Run with: python Dash_wildfire.py

All screenshots in the Screenshots folder were captured from the actual execution of
the script(s) above by MC664822 GAO TE. The Jupyter Notebook evidence for the same module is
submitted separately in the personal forum of the module.
