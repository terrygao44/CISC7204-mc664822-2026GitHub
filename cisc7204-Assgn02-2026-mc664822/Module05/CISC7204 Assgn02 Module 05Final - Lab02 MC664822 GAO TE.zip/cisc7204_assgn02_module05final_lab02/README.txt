CISC7204 Assignment 02 - Project Space
======================================

Module 05 Final - Lab02: Creating Dashboard using Plotly and Dash (Automobile Sales)

Pair            : Class K - Pair 05
Member          : MC664822 GAO TE
Pair partner    : MC664831 WEN ZIMING
Coursework item : CISC7204 Assignment 02 - Modules (01-05)
UMMoodle site   : Class K support site (26-1-CISC7204-00__72314)

Contents
--------
  DV0101EN-Final-Assign-Part-2-Questions.py
  Screenshots/Module05_FinalLab02_app_s01_initial.png
      Automobile Sales Statistics Dashboard - initial view
  Screenshots/Module05_FinalLab02_app_s02_recession_report.png
      Report type: Recession Report (statistics + 4 charts)
  Screenshots/Module05_FinalLab02_app_s03_yearly_report_year_2010.png
      Report type: Yearly Report with year 2010 selected
  Screenshots/RecessionReportgraphs.png
      Saved output required by the lab: RecessionReportgraphs.png
  Screenshots/YearlyReportgraphs.png
      Saved output required by the lab: YearlyReportgraphs.png
  Screenshots/Module05_FinalLab02_code_DV0101EN-Final-Assign-Part-2-Questions_code_p1.png
      Source code, page 1
  Screenshots/Module05_FinalLab02_code_DV0101EN-Final-Assign-Part-2-Questions_code_p2.png
      Source code, page 2
  Screenshots/Module05_FinalLab02_code_DV0101EN-Final-Assign-Part-2-Questions_code_p3.png
      Source code, page 3
  Screenshots/Module05_FinalLab02_code_DV0101EN-Final-Assign-Part-2-Questions_code_p4.png
      Source code, page 4
  Screenshots/Module05_FinalLab02_code_DV0101EN-Final-Assign-Part-2-Questions_code_p5.png
      Source code, page 5

Notes
-----
Run with: python DV0101EN-Final-Assign-Part-2-Questions.py

All screenshots in the Screenshots folder were captured from the actual execution of
the script(s) above by MC664822 GAO TE. The Jupyter Notebook evidence for the same module is
submitted separately in the personal forum of the module.
